param location string
param environment string
param projectName string

var tags = {
  Environment: environment
  Project: projectName
  Owner: 'PlatformTeam'
}

module rg './modules/resourceGroup.bicep' = {
  name: 'rg'
  params: {
    rgName: 'rg-${projectName}-${environment}'
    location: location
    tags: tags
  }
}

module law './modules/logAnalytics.bicep' = {
  name: 'logAnalytics'
  params: {
    name: 'law-${projectName}-${environment}'
    location: location
  }
}

module storage './modules/storage.bicep' = {
  name: 'storage'
  params: {
    name: 'st${projectName}${environment}'
    location: location
  }
}